package com.example.ej10_recycleview

data class SuperHero (
        val superhero:String,
        val publisher:String,
        val realName:String,
        val photo:String
)